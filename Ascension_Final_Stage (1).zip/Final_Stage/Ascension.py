# -*- coding: utf-8 -*-
"""
Created on Mon Dec 26 16:04:53 2022

@author: 
"""

#!/usr/bin/env python
# coding: utf-8
import sqlite3

# connect to the database that is named project.db in the same folder as this file
con = sqlite3.connect('project.db')

cur = con.cursor()

# impoerting the necessary libraries
import PySimpleGUI as sg
import numpy as np
import datetime
import random

# global variables
login_user_id = -1
login_user_name = -1
login_user_type = -1
selected_Video_ID = 1
selected_Ad_ID = None
selected_Ad_TypeID = None
selected_CompanyID = None
# window functions
def window_login():
    
    layout = [[sg.Text('Welcome to the Ascension Video Platform ', auto_size_text= True, font='Helvetica')],
              [sg.Text('Your User ID:', auto_size_text= True, font='Helvetica'), sg.Input(size=(10,1), key='id')],
              [sg.Text('Password:',auto_size_text= True, font='Helvetica' ), sg.Input(size=(10,1), key='password')],
              [sg.Button('Login')]]

    return sg.Window('Login Window', layout,size=(500,500), font='Helvetica',auto_size_buttons=True,auto_size_text=True,element_justification='c',element_padding=(10,10),margins=(55,55))



#----------------------------------------------------------------#
# öfönün kısmı

def window_admin():
    # Create the layout for the main window
    layout = [[sg.Text('Welcome ' + login_user_name)],
              [sg.Listbox(values=[], key='videos_list', size=(40, 10))],
              [sg.Button('Select_Video', key='select_video')],
              [sg.Button('Search', key='search_admin'), sg.Button('Payment Page', key='payment_page')],
              [sg.Button('Logout')]]

    window = sg.Window('Admin Window', layout,size=(500,500),font='Helvetica',auto_size_buttons=True,auto_size_text=True,element_justification='c',element_padding=(10,10),margins=(55,55))


    # Run the event loop for the main window
    admin_event_loop(window)

def admin_event_loop(window):
    # Load the list of videos with no advertisements
    cur.execute('''SELECT VideoID,Name,Description FROM Videos WHERE AdID is Null''')
    videos = cur.fetchall()

    # Create a list of video names to display in the Listbox
    video_names = [video[1] for video in videos]

    while True:
        event, values = window.read()

        # Update the Listbox with the list of video names
        window['videos_list'].update(video_names)

        if event in (None, 'Logout'):
            window.close()
            window = window_login()
        elif event == 'payment_page':
            window.close()
            window = payment_Page()
        elif event == 'search_admin':
            # TODO: Add code to search the database and update the Listbox with the search results
            pass
        elif event == 'select_video':
            if values==[] or values == None or values['videos_list'] == [] or values['videos_list'] == None:
                sg.popup('Please select a video')
                admin_event_loop(window)
            else:
                # Get the selected video name from the list
                selected_name = values['videos_list'][0]
                if selected_name is not None:
                    # Find the index of the selected video in the videos list
                    selected_index = None
                    for i, video in enumerate(videos):
                        if video[1] == selected_name:
                            selected_index = i
                            break
                    if selected_index is not None:
                        global selected_Video_ID
                        selected_Video_ID = videos[selected_index][0]
                        global selected_video_title
                        selected_video_title = videos[selected_index][1]
                        global selected_video_description
                        selected_video_description = videos[selected_index][2]
                        # Close the main window and open the video details window
                        window.close()
                        window = window_details_foradless_videos()
                        details_event_loop(window)

def window_details_foradless_videos():
    # Create the layout for the details window
    layout = [[sg.Text('Video Details fo AD')],
              [sg.Text('Name:', size=(10, 1)), sg.Text(selected_video_title, key='name')],
              [sg.Text('Description:', size=(10, 1)), sg.Text(selected_video_description, key='description')],
              [sg.Button('Add Advertisementfor adless videoes', key='add_ads')],
              [sg.Button('Close')]]

    window = sg.Window('Details Window for Adless Video', layout,size=(500,500),font='Helvetica',auto_size_buttons=True,auto_size_text=True,element_justification='c',element_padding=(10,10),margins=(55,55))
    
    # Run the event loop for the details window
    while True:
        event, values = window.read()
        if event in (None, 'Close'):
            window.close()
            
            window_admin()
            
        elif event == 'add_ads':
            
            window = display_AdsforVideo(selected_Video_ID)
        elif event == 'back':
            window.close()
            window_details_foradless_videos()
        elif event == sg.WIN_CLOSED:
            window.close()
            window_admin()
    

def details_event_loop(window):
    while True:
        event, values = window.read()

        if event in (None, 'Close'):
            window.close()
            break





#---------------------------------------------------------------#



#---------------------------------------------------------------#
#keremin yapması gereken kısımdı
def display_AdsforVideo(VideoID):
    #select from advertisement table name companyID content flag where given VideoID's Video_TypeID is equal to Ad_TypeID from Advertisement and Ad_TypeID is equal to Advertisement.Ad_TypeID
    cur.execute('''SELECT Name,CompanyID,Content,Flag, AdID, Ad_TypeID FROM Advertisement WHERE Ad_TypeID = (SELECT Video_TypeID FROM Videos WHERE VideoID = ?)''',(VideoID,))
    ads = cur.fetchall()
    layout = [[sg.Text('Available Ads')],
            [sg.Table(values=ads, headings=['Name', 'CompanyID', 'Content', 'Flag','AdID','Ad_TypeID'], auto_size_columns=True, key='table222', enable_events=True, justification='center', num_rows=20, alternating_row_color='lightblue', row_height=35, tooltip='This is a table')],
            [sg.Button('Back', key = 'back'), sg.Button('Assign', key = 'assign')]]
    window = sg.Window('Available Ads', layout,size=(800,800),font='Helvetica',auto_size_buttons=True,auto_size_text=True)
    while True:
        event, values = window.read()
        if event in (None, 'Close'):
            window.close()
            window_admin()
        elif event == 'back':
            window.close()
            window_details_foradless_videos()
        elif event == sg.WIN_CLOSED:
            window.close()
            window_admin()
        elif event == 'table222':
            print(values['table222'])
            row_id = values['table222'][0]
            print(row_id)
            print(ads)
            print(ads[row_id])
            global selected_Ad_ID
            selected_Ad_ID = ads[row_id][4]
            global selected_Ad_TypeID
            selected_Ad_TypeID= ads[row_id][5]
           

        elif event == 'assign':
            # set the AdID and Ad_TypeID in videos table to selected AdID and Ad_TypeID

            print(selected_Ad_ID)
            print(selected_Ad_TypeID)
            if selected_Ad_ID is None or selected_Ad_TypeID is None:
                sg.popup('Please select an advertisement')
                continue
            else:
                cur.execute('''UPDATE Videos SET AdID = ? , Ad_TypeID = ? WHERE VideoID = ?''',(selected_Ad_ID,selected_Ad_TypeID,VideoID,))
                # set the flag of the advertisement to TRUE and set VideoID in advertisement table to VideoID
                cur.execute('''UPDATE Advertisement SET Flag = TRUE, VideoID = ? WHERE AdID = ?''',(selected_Ad_ID,VideoID,))
                con.commit()
                sg.popup('Advertisement assigned successfully')
                window.close()
                window_details_foradless_videos().update()
            

            



#---------------------------------------------------------------#

#---------------------------------------------------------------#
#EL MAMITO VEL MAMITO
def payment_Page():
    # from company select Company_Name, CompanyID, IBAN_Information,Foundation_Year, CompanyID
    cur.execute('''SELECT Company_Name, IBAN_Information,Foundation_Year, CompanyID FROM Company''')
    rows = cur.fetchall()
    # from users select Name,E-Mail from Partner select IBAN_Information where partner.UserID = users.UserID
    cur.execute('''SELECT U.Name, U.E_Mail , P.IBAN_Information, P.UserID FROM Users U, Partner P WHERE U.UserID = P.UserID''')
    rows2 = cur.fetchall()


    layout = [[sg.Text('Payment Page')],
              [sg.Table(values=rows, headings=['Company Name', 'IBAN Information','Foundation Year','CompanyID'], auto_size_columns=True, key='table333', enable_events=True, justification='center', num_rows=20, alternating_row_color='lightblue', tooltip='This is a table')],
              #[sg.Button('Back', key = 'back')]
              [sg.Table(values=rows2, headings=['Name', 'E-Mail', 'IBAN Information','UserID'], auto_size_columns=True, key='table444', enable_events=True, justification='center', num_rows=20, alternating_row_color='lightblue', tooltip='This is a table')],
              [sg.Button('Close')]]
    
    window = sg.Window('Payment Page', layout,size=(1000,800),font='Helvetica',auto_size_buttons=True,auto_size_text=True)
    while True:
        event, values = window.read()
        if event in (None, 'Close'):
            window.close()
        elif event == sg.WIN_CLOSED:
            window.close()
            window_admin()
        
        elif event == 'table333':
            row_id = values['table333'][0]
            global selected_CompanyID
            selected_CompanyID = rows[row_id][3]
            window = show_company_advertisements(selected_CompanyID)
            
        elif event == 'table444':
            
            row_id = values['table444'][0]
            
            global selected_UserID
            selected_UserID = rows2[row_id][3]
            window = show_partner_advertisements_of_companies(selected_UserID)

def show_company_advertisements(companyID):
    cur.execute('''SELECT AdID, Ad_TypeID, Name, Content, VideoID, Flag FROM Advertisement WHERE CompanyID = ?''',(companyID,))
    rows = cur.fetchall()
    layout = [[sg.Text('Company Advertisements')],
                [sg.Table(values=rows, headings=['AdID', 'Ad_TypeID', 'Name', 'Content', 'VideoID', 'Flag'], auto_size_columns=True, key='table555', enable_events=True, justification='center', num_rows=20, alternating_row_color='lightblue', tooltip='This is a table')],
                [sg.Button('Close')]]
    window = sg.Window('Company Advertisements', layout,size=(1000,800),font='Helvetica',auto_size_buttons=True,auto_size_text=True)
    return window

def show_partner_advertisements_of_companies(partnerID):

    #SELECT C.Company_Name, C.IBAN_Information, A.Name, A.Content FROM Company C, Advertisement A, Videos V WHERE C.CompanyID = A.Company AND V.VideoID = A.VideoID AND V.UserID = (SELECT UserID FROM Partner WHERE PartnerID = ?)
    # SELECT C.Company_Name, C.IBAN_Information, A.Name, A.Content FROM Company C, Advertisement A, Videos V WHERE C.CompanyID = A.Company
    # AND V.VideoID = A.VideoID AND V.UserID = (SELECT UserID FROM Partner WHERE PartnerID = ?)
    cur.execute('''SELECT C.Company_Name, C.IBAN_Information, A.Name, A.Content, AdID FROM Company C, Advertisement A, Upload U WHERE C.CompanyID = A.CompanyID
    AND A.VideoID = U.VideoID AND U.UserID = (SELECT UserID FROM Partner WHERE UserID = ?)''',(partnerID,))
    rows = cur.fetchall()

    layout = [[sg.Text('Partner\'s Company ADs')],
            [sg.Table(values=rows, headings=['Company Name', 'Company IBAN', 'ADName', 'Content', 'AdID'], auto_size_columns=True, key='table666', enable_events=True, justification='center', num_rows=20, alternating_row_color='lightblue', tooltip='This is a table')],
            [sg.Button('Close'), sg.Button('Pay', key='pay1')]]
    window = sg.Window('Company Advertisements', layout,size=(1000,800),font='Helvetica',auto_size_buttons=True,auto_size_text=True)
    
    while True:
        event, values = window.read()
        if event in (None, 'Close'):
            window.close()
            break
        elif event == sg.WIN_CLOSED:
            window.close()
            window_admin()
        elif event == 'pay1':
            if values['table666'] == [] or values['table666'] == None:
                sg.popup('Please select an AD to pay')
            else:
                row_id = values['table666'][0]
                print(row_id)
                global selected_AdID
                selected_AdID = rows[row_id][4]
                window = payment_to_Partner(selected_Ad_ID,partnerID) 


def payment_to_Partner(AdID,PartnerID):

    #FROM Payment P take transaction_number and create a new transaction_number inceremented by 1 and assign AdID and amount to it, take newly created transaction_number and PartnerID and create a new row in Receive R
    layout = [[sg.Text('Payment Page')],
            [sg.Text('Enter Amount to pay: ', sg.Input(size=(10,1), key='amount'))],
            [sg.Button('Back'), sg.Button('Pay', key='pay')]]

    window = sg.Window('Payment Page', layout,size=(1000,800),font='Helvetica',auto_size_buttons=True,auto_size_text=True)
    

    while True:
        event, values = window.read()
        if event in (None, 'Close'):
            window.close()
            break
        elif event=='Back':
            window.close()
            window_admin()
        elif event == sg.WIN_CLOSED:
            window.close()
            window_admin()
        elif event == 'pay':
            cur.execute('''SELECT Transaction_Number FROM Payment''')
            rows = cur.fetchall()
            transaction_number = rows[-1][0] + 1
            print(transaction_number)
            cur.execute('''INSERT INTO Payment (Transaction_Number, AdID, Amount) VALUES (?,?,?)''',(transaction_number,AdID,amount))
            cur.execute('''INSERT INTO Receive (Transaction_Number, PartnerID) VALUES (?,?)''',(transaction_number,PartnerID))
            con.commit()
            sg.popup('Payment is done successfully')






#---------------------------------------------------------------#
def window_standard():

    layout = [[sg.Text('Welcome ' + login_user_name)],
              [sg.Button('All Videos')],
              [sg.Button('Search')],
              [sg.Button('Logout')]]

    return sg.Window('Standard Window', layout,size=(500,500),font='Helvetica',auto_size_buttons=True,auto_size_text=True,element_justification='c',element_padding=(10,10),margins=(55,55))

def window_partner():
    # needs to be updated for the values and options given in the functional requirements sheet
    layout = [[sg.Text('Welcome ' + login_user_name)],
              [sg.Button('My Videos')],
              [sg.Button('Logout')]]

    window = sg.Window('Partner Window', layout,size=(500,500),font='Helvetica',auto_size_buttons=True,auto_size_text=True,element_justification='c',element_padding=(10,10),margins=(55,55))


    while True:
        event, values = window.read()

        if event == 'My Videos':
            window.close()
            my_videos(login_user_id)
            window = window_partner()
        elif event == 'Logout':
            window.close()
            
        elif event == sg.WIN_CLOSED:
            break

    window.close()

def button_login(values):
    
    global login_user_id
    global login_user_name
    global login_user_type
    global window
    
    uid = values['id']
    upass = values['password']
    
    if uid == '':
        sg.popup('ID cannot be empty')
    elif upass == '':
        sg.popup('Password cannot be empty')
    else:
        # first check if this is a valid user
        cur.execute('SELECT UserID, Name FROM Users WHERE UserID = ? AND Password = ?', (uid,upass))
        row = cur.fetchone()
        
        if row is None:
            sg.popup('ID or password is wrong!')
        else:
            # this is some existing user, let's keep the ID of this user in the global variable
            login_user_id = row[0]
            
            # we will use the name in the welcome message
            login_user_name = row[1]
            
            # now let's find which type of user this login_user_id belongs to
            
            cur.execute('SELECT UserID FROM Standard WHERE UserID = ?', (uid,))
            row_Standard = cur.fetchone()
            
            if row_Standard is None:
                # this is not a standart, let's check for admin
                cur.execute('SELECT UserID FROM Admin WHERE UserID = ?', (uid,))
                row_admin = cur.fetchone()
                if row_admin is None:
                    # this is not a admin, let'S check for partner
                    cur.execute('SELECT UserID FROM Partner WHERE UserID = ?', (uid,))
                    row_partner = cur.fetchone()
                    if row_partner is None:
                        sg.popup('User type error! Please contact the admin.')
                            
                    else:
                        
                        login_user_type = 'Partner'
                        sg.popup('Welcome, ' + login_user_name + ' (Partner)')
                        window.close()
                        window = window_partner()
                   
                    
                else:
                    
                    login_user_type = 'Admin'
                    sg.popup('Welcome, ' + login_user_name + ' (Admin)')
                    window.close()
                    window = window_admin()
            else:
                
                    login_user_type = 'Standard'
                    sg.popup('Welcome, ' + login_user_name + ' (Standard)')
                    window.close()
                    window = window_standard()

# a video details page that takes the videoID as input and gives th details of the video from table Videos, Users, Upload
def video_details(videoID):
    global window
    # get the video data from the database
    cur.execute('SELECT Videos.Name, Description, Duration, View_Count, Users.Name, Update_Date FROM Videos, Users, Upload WHERE Videos.VideoID = Upload.VideoID AND Users.UserID = Upload.UserID AND Videos.VideoID = ?', (videoID,))
    row = cur.fetchone()
    
    # display the video data in a table
    layout = [[sg.Text('Video Data')], 
              [sg.Text('Name: '), sg.Text(row[0])],
              [sg.Text('Description: '), sg.Text(row[1])],
              [sg.Text('Duration: '), sg.Text(row[2])],
              [sg.Text('View Count: '), sg.Text(row[3])],
              [sg.Text('Uploader: '), sg.Text(row[4])],
              [sg.Text('Uploaded: '), sg.Text(row[5])],
              [sg.Button('Back')]]
    
    window.close()
    window = sg.Window('Video Data', layout)

def remove_char(string):
    string = string.replace("'","")
    string = string.replace(",","")
    string = string.replace("(","")
    string = string.replace(")","")
    string = string.replace(".","")
    return string

def show_video_data():
    # this function will show the video data in a table
    global window
    
    # get the video data from the database
    cur.execute('SELECT Videos.Name, Description, Duration, View_Count, Users.Name FROM Videos, Users, Upload WHERE Videos.VideoID = Upload.VideoID AND Users.UserID = Upload.UserID')
    rows = cur.fetchall()
    # get update_date from database and use time_dif function to get the exact date
    cur.execute('SELECT Update_Date FROM Upload')
    rowsdate = cur.fetchall()
    appdate = []
    for row in rowsdate:
        #split split integer as year, month, day
        date = str(row)
        date= remove_char(date)
        
        year = int(date[0:4])
        month = int(date[4:6])
        day = int(date[6:8])
        appdate.append(str(time_dif(year, month, day)+" ago"))
    # add the update_date list to the rows array
    # vstack appdate to rows
    newrows = []
    for i in range(len(rows)):
        newrows.append(list(rows[i]) + [appdate[i]])


        
    # display the video data in a table
    layout = [[sg.Text('Video Data')],
            [sg.Button('Filter')],
            [sg.Table(values=newrows, headings=['Name', 'Description','Duration', 'View Count', 'User Uploader', 'Uploaded'], max_col_width=25, auto_size_columns=False, justification='left', num_rows=20, key='table')],
            [sg.Button('Back')]]
    
    window.close()
    window = sg.Window('Video Data', layout)

# filter the videos by type or tag from table Videos, Tags, Video_Type
def filter_video():
    global window
    # get the video data from the database
    tagfilter = sg.popup_get_text('Enter the tag name')
    typefilter = sg.popup_get_text('Enter the type name')
    cur.execute("SELECT DISTINCT V.Name, V.Description, V.Like_Count, V.Dislike_Count, V.View_Count FROM Videos AS V, Keep AS K , Tags AS T, Video_Type AS VT WHERE (K.VideoID = V.VideoID AND V.Video_TypeID= VT.Video_TypeID AND VT.VType_Description LIKE ?) OR (V.VideoID = K.VideoID AND T.TagID = K.TagID AND T.Tag_Name LIKE ?)",(typefilter, tagfilter))
    rows = cur.fetchall()
    # make new window
    layout = [[sg.Text('Video Data Filtered')],
            [sg.Button('Filter')], 
            [sg.Table(values=rows, headings=['Name', 'Description', 'Like Count', 'Dislike Count', 'View Count'], max_col_width=25, auto_size_columns=False, justification='left', num_rows=20, key='table')],
            [sg.Button('Back')]]

    window= sg.Window('Video Data Filtered', layout)
    
    return rows

def time_dif(year, month, day):
    today = datetime.datetime.now()
    video_date = datetime.datetime(year, month, day)
    difference = today - video_date

    #transform to second
    time_sec = difference.total_seconds()

    #convert to day
    date_day = time_sec / (60*60*24)
    if date_day.is_integer() is False :
        exact_date = date_day + 1
    else:
        exact_date = date_day
    
    #check if video published months or years ago
    if (exact_date) <= 31:
        result = (exact_date-1) // 1
        printed = str(result) + " day"

    elif exact_date > 31 and date_day <= 365:
        result = (exact_date+1) // 31
        printed = str(result) + " month"

    elif exact_date > 365:
        result = (exact_date) // 365
        printed = str(result) + " year"

    return printed

# a video page that have the details of the video such as Name , Description, Duration, View Count, User Uploader, Upload Date, Like Count, Dislike Count and return  to the search page
def search_video():
    global window
    # get the video data from the database
    search = sg.popup_get_text('Enter the video name')
    cur.execute('SELECT Videos.Name, Description, Duration, View_Count, Users.Name, Update_Date, Videos.VideoID FROM Videos, Users, Upload WHERE Videos.VideoID = Upload.VideoID AND Users.UserID = Upload.UserID AND Videos.Name LIKE ?', (search,))
    rows = cur.fetchall()
    if  rows == []:
        sg.popup('There is no video with this name')
    else:
        
        # display the video data in a table
        layout = [[sg.Text('Video Data')],
                [sg.Table(values=rows, headings=['Name', 'Description','Duration', 'View Count', 'User Uploader', 'Uploaded', 'VideoID'], max_col_width=25, justification='left', num_rows=20, key='table', enable_events=True, bind_return_key=True, row_height=30, auto_size_columns=True, text_color='black', background_color='white', font='Helvetica 14', visible_column_map=[0,1,2,3,4,5])],
                [sg.Button('Back')]]
        
        
        window = sg.Window('Video Data', layout)
        #get new window by clicking row
        
        while True:
            
            event, values = window.read()
            # get VideoID from clicked row
            print(event)
            print(values)
            if event == 'table':
                VideoID1 = values['table']
                VideoID=rows[(VideoID1[0])][6]
                selected_Video_ID = VideoID
                
                break
                
            
            elif event == 'Back':
                window.close()
                window = window_standard()
                
            elif event == sg.WIN_CLOSED:
                break   
def like_count_increment(VideoID):
    # get the video data from the database
    cur.execute('SELECT Like_Count FROM Videos WHERE VideoID = ?', (VideoID,))
    rows = cur.fetchall()
    like_count = rows[0][0]
    like_count += 1
    cur.execute('UPDATE Videos SET Like_Count = ? WHERE VideoID = ?', (like_count, VideoID))
    con.commit()
    
def dislike_count_increment(VideoID):
    # get the video data from the database
    cur.execute('SELECT Dislike_Count FROM Videos WHERE VideoID = ?', (VideoID,))
    rows = cur.fetchall()
    dislike_count = rows[0][0]
    dislike_count += 1
    cur.execute('UPDATE Videos SET Dislike_Count = ? WHERE VideoID = ?', (dislike_count, VideoID))
    con.commit()
    
def view_count_increment(VideoID):
    # get the video data from the database
    cur.execute('SELECT View_Count FROM Videos WHERE VideoID = ?', (VideoID,))
    rows = cur.fetchall()
    view_count = rows[0][0]
    view_count += 1
    cur.execute('UPDATE Videos SET View_Count = ? WHERE VideoID = ?', (view_count, VideoID))
    con.commit()


# My_VIDEOS -----------------------------------------------------------------------------------------
def my_videos(login_user_id):
    global window
    # get the video data from the database
    cur.execute(
        'SELECT DISTINCT Videos.Name, Description, Like_Count , Dislike_Count, View_Count, Tag_Name, Videos.VideoID FROM Videos, Users, Partner, Keep, Tags, Upload WHERE Upload.UserID = Partner.UserID AND Videos.VideoID = Keep.VideoID AND Keep.TagID = Tags.TagID AND Upload.VideoID = Videos.VideoID AND Partner.UserID = ?',
        (login_user_id,))
    rows = cur.fetchall()

    if rows == []:
        sg.popup('There is no video with this partner')
    else:
        # display the video data in a table
        layout = [[sg.Text('My Videos')],
                  [sg.Table(values=rows,
                            headings=['Name', 'Description', 'like count', 'dislike count', 'View Count',"Tag Name", "VideoID"],
                            max_col_width=25, auto_size_columns=False, justification='left', num_rows=20,
                            key='my_video_table',
                            enable_click_events=True, enable_events=True, bind_return_key=True,
                            visible_column_map=[0, 1, 2, 3, 4, 5, 6])],
                  [sg.Button('Delete'), sg.Button('Create A New Video')],
                  [sg.Button('Edit'), sg.Text('New Name:', auto_size_text=True, font='Helvetica'),
                   sg.Input(size=(10, 1), key='name'),
                   sg.Text(' New Description:', auto_size_text=True, font='Helvetica'),
                   sg.Input(size=(10, 1), key='description')],
                  [sg.Button('Back'), sg.Text('New Tag:', auto_size_text=True, font='Helvetica'),sg.Input(size=(10, 1), key='tag')]
                  ]
        window = sg.Window('My Videos', layout)
        
        video_id = -1
        print(rows)
        while True:

            event, values = window.read()
            # get VideoID from clicked row

            if event == 'my_video_table':
                selected_video = values['my_video_table']
                video_id = rows[(selected_video[0])][6]
              
            elif event == 'Delete':
                if video_id == -1:
                    sg.popup("Please select a video first!")
                else:
                    delete_video(video_id)
                    my_videos(login_user_id).refresh()
                    
            elif event == 'Edit':
                if video_id == -1:
                    sg.popup("Please select a video first!")
                else:
                    edit_video(video_id, values)
                    my_videos(login_user_id).refresh()
                    
            elif event == 'Back':
                window.close()
                window = window_partner()
            elif event == 'Create A New Video':
                window.close()
                create_video_screen()


            elif event == sg.WIN_CLOSED:
                break


def delete_video(video_id):
    check_delete = sg.popup_yes_no("Are you sure?")
    if check_delete == "Yes":
        cur.execute('DELETE FROM Videos WHERE VideoID = ?', (video_id,))
    con.commit()


def edit_video(video_id, values):
    name = values["name"]
    desc = values["description"]
    tag = values["tag"]
    
    cur.execute("SELECT MAX(TagID) + 1  FROM Tags")
    tag_id = cur.fetchone()
    cur.execute("SELECT Tag_Name FROM Tags")
    tag_names = cur.fetchall()
    
    
    if name == '':
        sg.popup('Please write the new name.')
    elif desc == '':
        sg.popup('Please write the new description.')
    elif tag == '':
        sg.popup('Please write the new tag.')            
    else:
        
        cur.execute(
            'UPDATE Videos SET Name = ? , Description = ?  WHERE VideoID = ? ',
            (name, desc, video_id))
        
        
        
        
        if tag not in tag_names:
                cur.execute("INSERT INTO Tags (TagID, Tag_Name) VALUES(?, ?) ",(int(tag_id[0]), tag))
                con.commit()
                cur.execute("INSERT or IGNORE INTO Keep (TagID, VideoID) VALUES(?, ?)" ,(int(tag_id[0]), video_id))
                cur.execute('UPDATE Keep SET TagID = ? WHERE VideoID =?', (int(tag_id[0]),video_id))
                con.commit()
        elif tag in tag_names:
                cur.execute("SELECT TagID FROM Tags WHERE Tag_Name LIKE ?" ,(tag))
                tag_id1 = cur.fetchone()
                cur.execute("INSERT INTO Keep (TagID, VideoID) VALUES(?, ?)" ,(int(tag_id1[0]), video_id))
                
                
        sg.popup('Selected video\'s name and description set to' + ' ' + name + ',' + desc)

        con.commit()
#---------------------------------------------------------------------------------------------------------------------

def generate_random_ip():
    return f"{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}"

def create_video(video_name, description, duration, ad_type, video_type):
    
    # insert the new video into the database
    like_count = 0
    view_count = 0
    dislike_count = 0
    ip_address = generate_random_ip()
    visibility = 'FALSE'
    cur.execute("SELECT MAX(VideoID) + 1  FROM Videos")
    video_id = cur.fetchone()
    cur.execute("SELECT Ad_TypeID FROM Ad_Type WHERE Ad_Description LIKE ?",([ad_type]))
    ad_id = cur.fetchone()
    cur.execute("SELECT Video_TypeID FROM Video_Type WHERE VType_Description LIKE ?",([video_type]))
    vtype_id = cur.fetchone()
    cur.execute("INSERT INTO Videos (VideoID, Name, Description, Duration, Like_Count, Dislike_Count, View_Count, Ad_TypeID, Video_TypeID, Visibility, IP_Adress) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", (video_id[0], video_name, description, duration, like_count, dislike_count, view_count, ad_id[0], vtype_id[0], visibility, ip_address))
    con.commit()
    # Get the current date and time
    now = datetime.datetime.now()
    date_string = now.strftime("%Y.%m.%d")
    
    # Insert the current date and time, along with the UserID and VideoID, into the Upload table
    cur.execute("INSERT INTO Upload (UserID, VideoID, Upload_Date) VALUES(?, ?, ?)", (login_user_id, video_id[0], date_string))
    con.commit()
    
    # Do not close the database connection


def create_video_screen():
    
    list_of_ad_types = []
    cur.execute("SELECT DISTINCT Ad_Description FROM Ad_Type")
    rows = cur.fetchall()
    for row in rows:
        list_of_ad_types.append(row[0])
        
    list_of_video_types = []
    cur.execute("SELECT VType_Description FROM Video_Type")
    rows = cur.fetchall()
    for row in rows:
        list_of_video_types.append(row[0])
    
    # define the variables and create the layout for the GUI
    layout = [    
        [sg.Text('Enter the details of the video:')],
        [sg.Text('Name:'), sg.InputText(key='video_name')],
        [sg.Text('Description:'), sg.InputText(key='description')],
        [sg.Text('Duration:'), sg.InputText(key='duration')],
        [sg.Text('Video Type:'), sg.InputCombo(list_of_video_types, key='vtype_name')],
        [sg.Text('Advertisement Preference:'), sg.InputCombo(['Yes', 'No'], key='ad_flag') ],
        [sg.Text('Tags:', key='tags_label'), sg.Button('+', key='add_tag_button')],
        [sg.Multiline(key='tags_input', size=(20, 1))],
        [sg.Text('Ad Type:'), sg.InputCombo(list_of_ad_types, key='ad_type', disabled=False)],
        [sg.Button('Create Video'), sg.Button('Back')]
        ]

# create the window and show it to the user
# Initialize an empty list to store the tags
    tags = []

# Create the window
    window = sg.Window('Create Video', layout,size=(800,800), font='Helvetica',auto_size_buttons=True,auto_size_text=True,element_justification='c',element_padding=(10,10),margins=(55,55))


# Event loop
    while True:
        event, values = window.read()
        if event in (None, 'Back'):
            break
        elif event == 'add_tag_button':
        # Get the new tag from the input field
            new_tag = values['tags_input']
        # Add the new tag to the list of tags
            tags.append(new_tag)
        # Update the tags label with the updated list of tags
            window['tags_label'].update(', '.join(tags))
        # Clear the tags input field
            window['tags_input'].update('')
        elif event == 'Create Video':
        # Create the video using the entered values
            create_video(values['video_name'], values['description'], values['duration'], values['vtype_name'], values['ad_flag'], tags, values['ad_type'])
            break

    window.close()
           

#----------------------------------------------------

def VideoPage(VideoID):
    global window
    # get the video data from the database
    cur.execute('SELECT Videos.Name, Description, Duration, View_Count, Users.Name, Update_Date, Like_Count, Dislike_Count FROM Videos, Users, Upload WHERE Videos.VideoID = Upload.VideoID AND Users.UserID = Upload.UserID AND Videos.VideoID = ?', (VideoID,))
    rows = cur.fetchall()
    
    
    # display the video data in a table
    layout = [[sg.Text('Video Data Expanded')], 
            [sg.Table(values=rows, headings=['Name', 'Description','Duration', 'View Count', 'User Uploader', 'Uploaded','like count','dislike count'], max_col_width=25, auto_size_columns=False, justification='left', num_rows=20, key='table')],
            [sg.Button('Like'), sg.Button('Dislike')],
            [sg.Button('Back')]]
    
    view_count_increment(VideoID)
    window = sg.Window('Video Data Expanded', layout)
    #get new window by clicking row


# open the first window
window = window_login()

while True:
    event, values = window.read()
    if event == 'Login':
        print(values)
        button_login(values)
    elif event == 'Like':
        like_count_increment(selected_Video_ID)
    elif event == 'Dislike':
        dislike_count_increment(selected_Video_ID)
    elif event== 'Back':
        window.close()
        window = window_standard()
    elif event == 'All Videos':
        print(values)
        show_video_data()
    elif event == 'Search':
        search_video()
    elif event == 'table':
        window.close()
        VideoPage(selected_Video_ID) 

    elif event == 'Filter':
        filter_video()
        
    elif event == 'Return To Main':
        if login_user_type == 'Admin':
            window.close()
            window = window_admin()
        elif login_user_type == 'Standard':
            window.close()
            window = window_standard()
        elif event == 'search':
            window.close()
            window = search_video()
        else:
            # this should not happen, bu in case happens let's return to login window
            window.close()
            window = window_login()
    elif event == 'Logout':
        # set login user global parameters
        login_user_id = -1
        login_user_name = -1
        login_user_type = -1
        window.close()
        window = window_login()
    #close the WIN_CLOSED window

    elif event == sg.WIN_CLOSED:
        break
        


window.close()

con.commit()
con.close()